package com.ge.hc.iow.rs.rule.utils;

public class WiringInput {
	
	String code;
	String name;
	String value;

}
