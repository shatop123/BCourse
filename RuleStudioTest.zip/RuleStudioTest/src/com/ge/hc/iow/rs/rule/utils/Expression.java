/**
 * 
 */
package com.ge.hc.iow.rs.rule.utils;

/**
 * @author 305015836
 *
 */
public class Expression {
	String name;
	String operator;
	String thresholdValue;
	String[] thresholdValues;

	public String[] getThresholdValues() {
		return thresholdValues;
	}

	public void setThresholdValues(String[] thresholdValues) {
		this.thresholdValues = thresholdValues;
	}

	String expressionType;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name
	 *            the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the operator
	 */
	public String getOperator() {
		return operator;
	}

	/**
	 * @param operator
	 *            the operator to set
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}

	/**
	 * @return the thresholdValue
	 */
	public String getThresholdValue() {
		return thresholdValue;
	}

	/**
	 * @param thresholdValue
	 *            the thresholdValue to set
	 */
	public void setThresholdValue(String thresholdValue) {
		this.thresholdValue = thresholdValue;
	}

	/**
	 * @return the expressionType
	 */
	public String getExpressionType() {
		return expressionType;
	}

	/**
	 * @param expressionType
	 *            the expressionType to set
	 */
	public void setExpressionType(String expressionType) {
		this.expressionType = expressionType;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("Expression [");
		if (name != null) {
			builder.append("name=");
			builder.append(name);
			builder.append(", ");
		}
		if (operator != null) {
			builder.append("operator=");
			builder.append(operator);
			builder.append(", ");
		}
		if (thresholdValue != null) {
			builder.append("thresholdValue=");
			builder.append(thresholdValue);
			builder.append(", ");
		}
		if (thresholdValues != null) {
			int i=0;
			while(i<thresholdValues.length){
			builder.append("thresholdValues=");
			builder.append(thresholdValues[i]);
			builder.append(", ");
			i++;
			}
		}
		if (expressionType != null) {
			builder.append("expressionType=");
			builder.append(expressionType);
		}
		builder.append("]");
		return builder.toString();
	}

}
