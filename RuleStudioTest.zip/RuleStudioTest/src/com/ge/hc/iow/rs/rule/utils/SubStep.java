/* ************************************************************************
 * $RCSfile: $
 * $Revision: $
 * Author : Senthil N
 * Created on Aug 19, 2015
 * 
 * Copyright 2015 THE GENERAL ELECTRIC COMPANY.
 * This software is the confidential and proprietary information of the
 * General Electric Company (GE). You shall not disclose this software and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with GE.
 *
 * $Log: $
 * ************************************************************************/

package com.ge.hc.iow.rs.rule.utils;

import java.util.Set;

public class SubStep {
	
	Integer subStepNumber;
	Set<String> wiringInput;
	Object wiringOutput;
	String expression;
	Long timePeriodInMilliSeconds;
	String functionName;
	String nextSubStep;
		
	public Integer getSubStepNumber() {
		return subStepNumber;
	}
	public void setSubStepNumber(Integer subStepNumber) {
		this.subStepNumber = subStepNumber;
	}
	public Set<String> getWiringInput() {
		return wiringInput;
	}
	public void setWiringInput(Set<String> wiringInput) {
		this.wiringInput = wiringInput;
	}
	public Object getWiringOutput() {
		return wiringOutput;
	}
	public void setWiringOutput(Object wiringOutput) {
		this.wiringOutput = wiringOutput;
	}
	public String getExpression() {
		return expression;
	}
	public void setExpression(String expression) {
		this.expression = expression;
	}
	public Long getTimePeriodInMilliSeconds() {
		return timePeriodInMilliSeconds;
	}
	public void setTimePeriodInMilliSeconds(Long timePeriodInMilliSeconds) {
		this.timePeriodInMilliSeconds = timePeriodInMilliSeconds;
	}
	public String getFunctionName() {
		return functionName;
	}
	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}
	

}
