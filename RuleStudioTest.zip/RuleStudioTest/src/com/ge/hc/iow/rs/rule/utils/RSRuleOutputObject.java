/**
 * 
 */
package com.ge.hc.iow.rs.rule.utils;

import java.util.Calendar;
import java.util.Map;
import java.util.Set;


/**
 * @author 305015836
 *
 */
public class RSRuleOutputObject 
{
	private String ruleID;	
	private int ruleVersion;
	private Calendar timeStamp = null;
	private Set<SystemMonitoredProperties> triggeredData;	
	private Map<Object, Object> ruleDataMap;
	
	
	/**
	 * @return the ruleVersion
	 */
	public int getRuleVersion() {
		return ruleVersion;
	}
	/**
	 * @param ruleVersion the ruleVersion to set
	 */
	public void setRuleVersion(int ruleVersion) {
		this.ruleVersion = ruleVersion;
	}
	/**
	 * @return the ruleID
	 */
	public String getRuleID() {
		return ruleID;
	}
	/**
	 * @param ruleID the ruleID to set
	 */
	public void setRuleID(String ruleID) {
		this.ruleID = ruleID;
	}
	
	
	/**
	 * @return the timeStamp
	 */
	public Calendar getTimeStamp() {
		return timeStamp;
	}
	/**
	 * @param timeStamp the timeStamp to set
	 */
	public void setTimeStamp(Calendar timeStamp) {
		this.timeStamp = timeStamp;
	}
	/**
	 * @param triggeredData the triggeredData to set
	 */
	public void setTriggeredData(Set<SystemMonitoredProperties> triggeredData) {
		this.triggeredData = triggeredData;
	}
	/**
	 * @return the triggeredData
	 */
	public Set<SystemMonitoredProperties> getTriggeredData() {
		return triggeredData;
	}
	
	/**
	 * @return the ruleDataMap
	 */
	public Map<Object, Object> getRuleDataMap() {
		return ruleDataMap;
	}
	/**
	 * @param ruleDataMap the ruleDataMap to set
	 */
	public void setRuleDataMap(Map<Object, Object> ruleDataMap) {
		this.ruleDataMap = ruleDataMap;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RSRuleOutputObject [");
		if (ruleID != null) {
			builder.append("ruleID=");
			builder.append(ruleID);
			builder.append(", ");
		}
		builder.append("ruleVersion=");
		builder.append(ruleVersion);
		builder.append(", ");
		if (triggeredData != null) {
			builder.append("triggeredData=");
			builder.append(triggeredData);
			builder.append(", ");
		}
		if (ruleDataMap != null) {
			builder.append("ruleDataMap=");
			builder.append(ruleDataMap);
		}
		builder.append("]");
		return builder.toString();
	}
	
}
