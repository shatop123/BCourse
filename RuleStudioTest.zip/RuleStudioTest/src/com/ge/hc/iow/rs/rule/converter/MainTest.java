package com.ge.hc.iow.rs.rule.converter;

import java.io.File;
import java.io.IOException;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;

import com.ge.hc.iow.rs.rule.converter.JsonConverter.Task;



public class MainTest {

	public JsonConverter convert() throws JsonParseException, JsonMappingException, IOException {

		ObjectMapper objectMapper = new ObjectMapper();

		File file = new File("c:\\test\\small.json");

		JsonConverter jc = objectMapper.readValue(file, JsonConverter.class);
		
		return jc;
	
	}
	
	public int getLength() throws JsonParseException, JsonMappingException, IOException{
		
		ObjectMapper objectMapper = new ObjectMapper();

		File file = new File("c:\\test\\small.json");

		JsonConverter jc = objectMapper.readValue(file, JsonConverter.class);
		Task tsk=jc.task;
		return tsk.rules.length;
		
		
		
		
	}
	

}


