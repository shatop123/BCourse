package com.ge.hc.iow.rs.rule.converter;

import com.ge.hc.iow.rs.rule.utils.*;

import java.io.IOException;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;

import com.ge.hc.iow.rs.rule.converter.JsonConverter.Task;
import com.ge.hc.iow.rs.rule.converter.JsonConverter.Task.Rule;
import com.ge.hc.iow.rs.rule.converter.JsonConverter.Task.Rule.Steps;
import com.ge.hc.iow.rs.rule.converter.JsonConverter.Task.Rule.Steps.Substeps;

public class RuleStepsConstructor {
		
	
	
	public RuleSteps[] constructRuleSteps(MainTest mt) throws JsonParseException, JsonMappingException, IOException {
		JsonConverter jc = mt.convert();
		
		Task tsk = jc.task;
		RuleSteps[] ruleSteps=new RuleSteps[mt.getLength()];
		Rule[] ru = tsk.rules;
				
			int i=0;
			while(i<ru.length){
			LinkedList<Steps> steps = ru[i].steps;
				LinkedList<Step> realSteps = new LinkedList<Step>();
				int j = 0;
				while (j < steps.size()) {

					Substeps[] sub = steps.get(j).substeps;
					
					Set<SubStep> realSubSteps = new HashSet<SubStep>();
					int k = 0;
					while (k < sub.length) {
						
						SubStep subStep = new SubStep();
						int subStepNumber = Integer.parseInt(sub[k].number);
						long time=Long.parseLong(sub[k].timeperiod);
						String expression = sub[k].expression;
						String functionName = sub[k].function;
						subStep.setSubStepNumber(subStepNumber);
						subStep.setTimePeriodInMilliSeconds(time);
						subStep.setExpression(expression);
						subStep.setFunctionName(functionName);
						realSubSteps.add(subStep);

						k++;
					}

					Step step = new Step();
					Integer stepNumber = Integer.parseInt(steps.get(j).number);
					String operator = steps.get(j).operator;
					String names1=steps.get(j).name;
					step.setStepNumber(stepNumber);
					step.setOperator(operator);
					step.setSubStep(realSubSteps);
					step.setName(names1);
					realSteps.add(step);

					j++;
				}

				
				String ruleName = ru[i].name;
				
				String ruleId = ru[i].id;
				
				int ruleVersion = 1;
				ruleSteps[i]=new RuleSteps();
				ruleSteps[i].setRuleName(ruleName);
				ruleSteps[i].setRuleId(ruleId);
				ruleSteps[i].setRuleVersion(ruleVersion);
				ruleSteps[i].setStep(realSteps);

				
				i++;
				
			}
			
		
		
		
		return ruleSteps;	
	}
}
