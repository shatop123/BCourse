/**
 * 
 */
package com.ge.hc.iow.rs.rule.utils;

/**
 * @author 305015836
 *
 */
public class RulePropertiesReader {

}
