/**
 * 
 */
package com.ge.hc.iow.rs.rule.utils;

/**
 * @author 305015836
 *
 */
public class RuleSemanticsObject
{

	public String ruleName;
	public String ruleId;
	public int version = 1;
	public String step;
	public String wireInput;
	public String wireOutput;
	public int timePeriod;
	public String expression;
	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}
	/**
	 * @param ruleName the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	/**
	 * @return the ruleId
	 */
	public String getRuleId() {
		return ruleId;
	}
	/**
	 * @param ruleId the ruleId to set
	 */
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	/**
	 * @return the version
	 */
	public int getVersion() {
		return version;
	}
	/**
	 * @param version the version to set
	 */
	public void setVersion(int version) {
		this.version = version;
	}
	/**
	 * @return the step
	 */
	public String getStep() {
		return step;
	}
	/**
	 * @param step the step to set
	 */
	public void setStep(String step) {
		this.step = step;
	}
	/**
	 * @return the wireInput
	 */
	public String getWireInput() {
		return wireInput;
	}
	/**
	 * @param wireInput the wireInput to set
	 */
	public void setWireInput(String wireInput) {
		this.wireInput = wireInput;
	}
	/**
	 * @return the wireOutput
	 */
	public String getWireOutput() {
		return wireOutput;
	}
	/**
	 * @param wireOutput the wireOutput to set
	 */
	public void setWireOutput(String wireOutput) {
		this.wireOutput = wireOutput;
	}
	/**
	 * @return the timePeriod
	 */
	public int getTimePeriod() {
		return timePeriod;
	}
	/**
	 * @param timePeriod the timePeriod to set
	 */
	public void setTimePeriod(int timePeriod) {
		this.timePeriod = timePeriod;
	}
	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}
	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RuleSemanticsObject [");
		if (ruleName != null) {
			builder.append("ruleName=");
			builder.append(ruleName);
			builder.append(", ");
		}
		if (ruleId != null) {
			builder.append("ruleId=");
			builder.append(ruleId);
			builder.append(", ");
		}
		builder.append("version=");
		builder.append(version);
		builder.append(", ");
		if (step != null) {
			builder.append("step=");
			builder.append(step);
			builder.append(", ");
		}
		if (wireInput != null) {
			builder.append("wireInput=");
			builder.append(wireInput);
			builder.append(", ");
		}
		if (wireOutput != null) {
			builder.append("wireOutput=");
			builder.append(wireOutput);
			builder.append(", ");
		}
		builder.append("timePeriod=");
		builder.append(timePeriod);
		builder.append(", ");
		if (expression != null) {
			builder.append("expression=");
			builder.append(expression);
		}
		builder.append("]");
		return builder.toString();
	}
	
	

}
