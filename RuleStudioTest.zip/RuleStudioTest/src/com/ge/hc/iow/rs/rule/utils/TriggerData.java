/* ************************************************************************
 * $RCSfile: $
 * $Revision: $
 * Author : Senthil N
 * Created on Aug 19, 2015
 * 
 * Copyright 2015 THE GENERAL ELECTRIC COMPANY.
 * This software is the confidential and proprietary information of the
 * General Electric Company (GE). You shall not disclose this software and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with GE.
 *
 * $Log: $
 * ************************************************************************/

package com.ge.hc.iow.rs.rule.utils;

import java.util.Calendar;

/**
 * @author 305015836
 *
 */
public class TriggerData 
{
	private String name;	
	private Calendar triggerTime = null;
	private Calendar processedTime = Calendar.getInstance();
	
	protected long triggerTimeInMillis;

	protected long processedTimeInMillis;
	
	
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the logTimeInMillis
	 */
	public long getTriggerTimeInMillis() {
		return triggerTimeInMillis;
	}

	/**
	 * @param triggerTimeInMillis
	 *            the logTimeInMillis to set
	 */
	public void setTriggerTimeInMillis(long triggerTimeInMillis) {
		this.triggerTimeInMillis = triggerTimeInMillis;
		
		/*
		 * Set logTime also, as they are shadow of each other.
		 */
		Calendar triggerTime = Calendar.getInstance();
		triggerTime.setTimeInMillis(triggerTimeInMillis);
		this.triggerTime = triggerTime;
	}

	/**
	 * @return the processedTimeInMillis
	 */
	public long getProcessedTimeInMillis() {
		return processedTimeInMillis;
	}

	/**
	 * @param processedTimeInMillis
	 *            the processedTimeInMillis to set
	 */
	public void setProcessedTimeInMillis(long processedTimeInMillis) {
		this.processedTimeInMillis = processedTimeInMillis;

		/*
		 * Set processedTime also, as they are shadow of each other.
		 */
		Calendar processedTime = Calendar.getInstance();
		processedTime.setTimeInMillis(processedTimeInMillis);
		this.processedTime = processedTime;
	}

	public Calendar getTriggerTime() {
		return triggerTime;
	}

	public void setTriggerTime(Calendar triggerTime) {
		this.triggerTime = triggerTime;
		
		/*
		 * Set logTimeInMillis also, as they are shadow of each other.
		 */

		if (triggerTime != null) {
			this.triggerTimeInMillis = triggerTime.getTimeInMillis();
		}
	}

	public Calendar getProcessedTime() {
		return processedTime;
	}

	public void setProcessedTime(Calendar processedTime) {
		this.processedTime = processedTime;
		
		/*
		 * Set processedTimeInMillis also, as they are shadow of each other.
		 */

		if (processedTime != null) {
			this.processedTimeInMillis = processedTime.getTimeInMillis();
		}
		
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		
		if (name != null) {
			builder.append(name);			
		}
		
		return builder.toString();
	}
	
	
}
