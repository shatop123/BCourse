/* ************************************************************************
 * $RCSfile: SystemMonitoredProperties.java,v $
 * $Revision: 1.2 $
 * Author : Senthil N
 * Created on May 11, 2015
 * 
 * Copyright 2015 THE GENERAL ELECTRIC COMPANY.
 * This software is the confidential and proprietary information of the
 * General Electric Company (GE). You shall not disclose this software and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with GE.
 *
 * $Log: SystemMonitoredProperties.java,v $
 * Revision 1.2  2015/05/28 13:30:59  senthiln
 * Fixed issues during unit testing
 *
 * Revision 1.1  2015/05/19 16:55:25  senthiln
 * Initial Rule Studio changes for FFA R1.1
 *
 * ************************************************************************/

package com.ge.hc.iow.rs.rule.utils;

import java.util.Calendar;

import org.apache.commons.lang.builder.HashCodeBuilder;



/**
 * @author 305015836
 *
 */
public class SystemMonitoredProperties implements Cloneable, Comparable<SystemMonitoredProperties> 
{
	private String propertyCode = null;
	private String propertyDescription= null;
	private String monitorValue = null;
	private String alarmDetail = null;
	private String unit = null;
	private Calendar generatedAt = null;
	private Calendar receivedAt = null;
	private String propertyType = null;
	private String assetModel = null;
	private Calendar loadDate = null;	
	protected long generatedAtInMillis;	
	protected long receivedAtInMillis;


	public long getGeneratedAtInMillis()
	{
		return generatedAtInMillis;
	}

	
	public void setGeneratedAtInMillis(long generatedAtInMillis) 
	{
		this.generatedAtInMillis = generatedAtInMillis;
		
		/*
		 * Set receivedAt also, as they are shadow of each other.
		 */
		Calendar generatedAt = Calendar.getInstance();
		generatedAt.setTimeInMillis(generatedAtInMillis);
		this.generatedAt = generatedAt;
	}

	/**
	 * @return the endDateInMillis
	 */
	public long getReceivedAtInMillis() {
		return receivedAtInMillis;
	}

	/**
	 * @param endDateInMillis
	 *            the endDateInMillis to set
	 */
	public void setReceivedAtInMillis(long receivedAtInMillis) {
		this.receivedAtInMillis =receivedAtInMillis;
		
		/*
		 * Set receivedAt also, as they are shadow of each other.
		 */
		Calendar receivedAt = Calendar.getInstance();
		receivedAt.setTimeInMillis(receivedAtInMillis);
		this.receivedAt = receivedAt;
	}

	
	/**
	 * @return the propertyCode
	 */
	public String getPropertyCode() {
		return propertyCode;
	}
	/**
	 * @param propertyCode the propertyCode to set
	 */
	public void setPropertyCode(String propertyCode) {
		this.propertyCode = propertyCode;
	}
	/**
	 * @return the propertyDescription
	 */
	public String getPropertyDescription() {
		return propertyDescription;
	}
	/**
	 * @param propertyDescriptiob the propertyDescription to set
	 */
	public void setPropertyDescription(String propertyDescription) {
		this.propertyDescription = propertyDescription;
	}
	/**
	 * @return the monitorValue
	 */
	public String getMonitorValue() {
		return monitorValue;
	}
	/**
	 * @param monitorValue the monitorValue to set
	 */
	public void setMonitorValue(String monitorValue) {
		this.monitorValue = monitorValue;
	}
	/**
	 * @return the unit
	 */
	public String getUnit() {
		return unit;
	}
	/**
	 * @param unit the unit to set
	 */
	public void setUnit(String unit) {
		this.unit = unit;
	}
	/**
	 * @return the generatedAt
	 */
	public Calendar getGeneratedAt() {
		return generatedAt;
	}
	/**
	 * @param generatedAt the generatedAt to set
	 */
	public void setGeneratedAt(Calendar generatedAt) {
		this.generatedAt = generatedAt;
	}
	/**
	 * @return the receivedAt
	 */
	public Calendar getReceivedAt() {
		return receivedAt;
	}
	/**
	 * @param receivedAt the receivedAt to set
	 */
	public void setReceivedAt(Calendar receivedAt) {
		this.receivedAt = receivedAt;
	}
	/**
	 * @return the propertyType
	 */
	public String getPropertyType() {
		return propertyType;
	}
	/**
	 * @param propertyType the propertyType to set
	 */
	public void setPropertyType(String propertyType) {
		this.propertyType = propertyType;
	}
	
	
	/**
	 * @return the alarmDetail
	 */
	public String getAlarmDetail() {
		return alarmDetail;
	}
	/**
	 * @param alarmDetail the alarmDetail to set
	 */
	public void setAlarmDetail(String alarmDetail) {
		this.alarmDetail = alarmDetail;
	}
	/**
	 * @return the assetModel
	 */
	public String getAssetModel() {
		return assetModel;
	}
	/**
	 * @param assetModel the assetModel to set
	 */
	public void setAssetModel(String assetModel) {
		this.assetModel = assetModel;
	}
	/**
	 * @return the loadDate
	 */
	public Calendar getLoadDate() {
		return loadDate;
	}
	/**
	 * @param loadDate the loadDate to set
	 */
	public void setLoadDate(Calendar loadDate) {
		this.loadDate = loadDate;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("DeviceMonitoredProperties [");
		if (propertyCode != null) {
			builder.append("propertyCode=");
			builder.append(propertyCode);
			builder.append(", ");
		}
		if (propertyDescription != null) {
			builder.append("propertyDescription=");
			builder.append(propertyDescription);
			builder.append(", ");
		}
		if (monitorValue != null) {
			builder.append("monitorValue=");
			builder.append(monitorValue);
			builder.append(", ");
		}
		if (unit != null) {
			builder.append("unit=");
			builder.append(unit);
			builder.append(", ");
		}
		if (generatedAt != null) {
			builder.append("generatedAt=");
			builder.append(generatedAt.getTime());
			builder.append(", ");
		}
		if (receivedAt != null) {
			builder.append("receivedAt=");
			builder.append(receivedAt.getTime());
			builder.append(", ");
		}
		if (propertyType != null) {
			builder.append("propertyType=");
			builder.append(propertyType);
			builder.append(", ");
		}
		if (alarmDetail != null) {
			builder.append("alarmDetail=");
			builder.append(alarmDetail);
			builder.append(", ");
		}
		if (assetModel != null) {
			builder.append("assetModel=");
			builder.append(assetModel);
			builder.append(", ");
		}
		if (loadDate != null) {
			builder.append("loadDate=");
			builder.append(loadDate.getTime());
		}
		builder.append("]");
		return builder.toString();
	}
	
	@Override
	public Object clone() 
	{
		SystemMonitoredProperties newObj = null;
		try
		{
			newObj = (SystemMonitoredProperties) super.clone();
		} catch (CloneNotSupportedException e)
		{
			// this shouldn't happen, since we are Cloneable
		}
		if (this.generatedAt != null)
		{
			newObj.generatedAt = (Calendar) this.generatedAt.clone();
		}
		if (this.receivedAt != null)
		{
			newObj.receivedAt = (Calendar) this.receivedAt.clone();
		}
		return newObj;
	}

	@Override
	public int compareTo(SystemMonitoredProperties obj) {
		if (obj instanceof SystemMonitoredProperties)
		{
			return this.getGeneratedAt().compareTo(obj.getGeneratedAt());
		} else
		{
			throw (new IllegalArgumentException("Input parameter is not of type DeviceMonitoredProperties"));
		}
	}

	/**
	 * Compare based on propertyName and generatedAt property
	 */
	@Override
	public boolean equals(Object obj) {
		if (obj == null)
		{
			return false;
		}
		if (obj == this)
		{
			return true;
		}
		if (!(obj instanceof SystemMonitoredProperties))
		{
			return false;
		}
		if (obj.getClass() != getClass())
		{
			return false;
		}

		SystemMonitoredProperties devicePropObject = (SystemMonitoredProperties) obj;

		if (this.propertyCode.equalsIgnoreCase(devicePropObject.propertyCode) && this.generatedAt.equals(devicePropObject.generatedAt))
		{
			return true;
		} else
		{
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode()
	{
		return new HashCodeBuilder().append(propertyCode).append(generatedAt).toHashCode();

	}	


}
