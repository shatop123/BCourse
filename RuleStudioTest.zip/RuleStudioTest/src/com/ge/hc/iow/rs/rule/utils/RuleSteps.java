/* ************************************************************************
 * $RCSfile: $
 * $Revision: $
 * Author : Senthil N
 * Created on Aug 19, 2015
 * 
 * Copyright 2015 THE GENERAL ELECTRIC COMPANY.
 * This software is the confidential and proprietary information of the
 * General Electric Company (GE). You shall not disclose this software and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with GE.
 *
 * $Log: $
 * ************************************************************************/

package com.ge.hc.iow.rs.rule.utils;

import java.util.LinkedList;

/**
 * @author 305015836
 *
 */
public class RuleSteps 
{
	String ruleName;
	String ruleId;
	int ruleVersion;
	LinkedList<Step> step;
	
	/**
	 * @return the ruleName
	 */
	public String getRuleName() {
		return ruleName;
	}
	/**
	 * @param ruleName the ruleName to set
	 */
	public void setRuleName(String ruleName) {
		this.ruleName = ruleName;
	}
	/**
	 * @return the ruleId
	 */
	public String getRuleId() {
		return ruleId;
	}
	/**
	 * @param ruleId the ruleId to set
	 */
	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}
	/**
	 * @return the ruleVersion
	 */
	public int getRuleVersion() {
		return ruleVersion;
	}
	/**
	 * @param ruleVersion the ruleVersion to set
	 */
	public void setRuleVersion(int ruleVersion) {
		this.ruleVersion = ruleVersion;
	}
	/**
	 * @return the step
	 */
	public LinkedList<Step> getStep() {
		return step;
	}
	/**
	 * @param step the step to set
	 */
	public void setStep(LinkedList<Step> step) {
		this.step = step;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("RuleSteps [");
		if (ruleName != null) {
			builder.append("ruleName=");
			builder.append(ruleName);
			builder.append(", ");
		}
		if (ruleId != null) {
			builder.append("ruleId=");
			builder.append(ruleId);
			builder.append(", ");
		}
		builder.append("ruleVersion=");
		builder.append(ruleVersion);
		builder.append(", ");
		if (step != null) {
			builder.append("step=");
			builder.append(step);
		}
		builder.append("]");
		return builder.toString();
	}
	
	
	
	
}
