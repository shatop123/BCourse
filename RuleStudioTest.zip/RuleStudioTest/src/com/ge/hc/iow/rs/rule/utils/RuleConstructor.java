/**
 * 
 */
package com.ge.hc.iow.rs.rule.utils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOCase;
import org.apache.commons.io.filefilter.IOFileFilter;
import org.apache.commons.io.filefilter.TrueFileFilter;
import org.apache.commons.io.filefilter.WildcardFileFilter;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.drools.KnowledgeBase;
import org.drools.KnowledgeBaseFactory;
import org.drools.builder.KnowledgeBuilder;
import org.drools.builder.KnowledgeBuilderFactory;
import org.drools.builder.ResourceType;
import org.drools.definition.KnowledgePackage;
import org.drools.io.ResourceFactory;
import org.drools.runtime.StatelessKnowledgeSession;

import com.ge.hc.iow.rs.rule.converter.MainTest;
import com.ge.hc.iow.rs.rule.converter.RuleStepsConstructor;

/**
 * @author 305015836
 *
 */
public class RuleConstructor {
	String NEW_LINE = System.getProperty("line.separator");

	/**
	 * @param ruleSteps
	 * @return
	 */
	public String constructRule(RuleSteps ruleSteps) {
		/**
		 * Please note that we are creating 2 dummy rules in order to satisfy
		 * the templates I. START RULE - A DUMMY rule to just start the trigger.
		 * This is by default applicable to all the rules and this step is
		 * triggered II. OUTPUT/END RULE - A dummy rule to check if the last
		 * executed rule triggered and collect the appropriate output III. Each
		 * Sub-step check if the previous step triggered and then execute the
		 * sub-steps IV. Each Step, check if the sub-step got executed and then
		 * writes the step as triggered. V. Trigger of a STEP is based on
		 * operator - AND, OR, NA. If the Step has only single step and doesn't
		 * have Conditional operator like AND, OR then, its considered as NA.
		 * VI. If all the steps triggered, then the rule triggers. VII. Each
		 * sub-step collects the triggered data points in the "then" portion of
		 * the rule.
		 * 
		 * Functionality of the method is as below, 1. Initialize variables -
		 * Salience [Execution order of rule], maxStepNumber - Need for the
		 * output rule 2. Iterate the steps within the Rule steps 3. Get the Sub
		 * steps for the Step and iterate the Sub Step. 4. If the sub step has
		 * function of error code or property, load different templates based on
		 * various conditions A. Property value changed B. Property has
		 * Threshold value [limits] C. Property has String as Threshold value 4.
		 * Default loading as Error code/Property 5. Replace the contents in the
		 * template with actual values for Sub-step 6. Replace the contents for
		 * the STEP 7. Repeat the above steps, until all the step templates are
		 * written appropriately 8. Once all the steps are iterated, add the
		 * Output and replace contents and add it to Rule contents string.
		 * 
		 */
		String ruleData = null;
		Map<String, String> drlTemplates = getAllTemplates();

		/**
		 * 1. Initialize variables - Salience [Execution order of rule],
		 * maxStepNumber - Need for the output rule
		 */
		String ruleId = ruleSteps.getRuleId();
		int ruleVersion = ruleSteps.getRuleVersion();
		LinkedList<Step> steps = ruleSteps.getStep();
		StringBuilder ruleStringBuilder = new StringBuilder();
		int salience = 10000;
		String drlTemplate = null;
		String actualStartDrl = null;
		int maxStepNumber = steps.size();
		/**
		 * 1. START RULE - A DUMMY rule to just start the trigger. This is by
		 * default applicable to all the rules and this step is triggered
		 */
		drlTemplate = drlTemplates.get("START");
		if (drlTemplate != null) {
			actualStartDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId).replaceAll("<RULE_VERSION>", ruleVersion + "")
					.replaceAll("<SALIENCE>", salience + "");

		}
		ruleStringBuilder.append(actualStartDrl).append(NEW_LINE).append(NEW_LINE);

		/**
		 * 2. Iterate the steps within the Rule steps
		 */
		for (Step step : steps) {
			StringBuilder ruleStepStringBuilder = new StringBuilder();
			Integer stepNumber = step.getStepNumber();
			Integer previousStepNumber = stepNumber - 1;
			String operator = step.getOperator();
			Set<SubStep> subSteps = step.getSubStep();
			/**
			 * 3. Get the Sub steps for the Step and iterate the Sub Step.
			 */
			if (subSteps != null && !subSteps.isEmpty()) {
				StringBuilder ruleSubStepsStringBuilder = new StringBuilder();
				int subStepCount = 0;
				Map<String, String> subStepStrings = new HashMap<String, String>();
				for (SubStep subStep : subSteps) {
					++subStepCount;
					/**
					 * Decrement the Salience count, as high Salience rule
					 * executes first. Its in decending order
					 */
					--salience;
					Integer subStepNumber = subStep.getSubStepNumber();
					Set<String> wiringInput = subStep.getWiringInput();
					// Object wiringOutput = subStep.getWiringOutput();
					String expression = subStep.getExpression();
					Long timePeriodInMilliSeconds = subStep.getTimePeriodInMilliSeconds();
					String functionName = subStep.getFunctionName();
					String actualSubStepDrl = null;
					/**
					 * 4. If the sub step has function of error code or
					 * property, load different templates based on various
					 * conditions A. Property value changed B. Property has
					 * Threshold value [limits] C. Property has String as
					 * Threshold value 4. Default loading as Error code/Property
					 */
					if (functionName.equalsIgnoreCase("PROPERTY") || functionName.equalsIgnoreCase("ERRORCODE")) {
						/**
						 * Parse the expression based on the logic to form the
						 * expression from UI.
						 */
						Expression expressionObject = parseExpression(expression);
						if (expressionObject != null) {
							String conditionalOperator = expressionObject.getOperator().trim();
							String expressionType = expressionObject.getExpressionType();

							String name = expressionObject.getName();

							String thresholdValue = expressionObject.getThresholdValue();

							String[] thresholdValues = expressionObject.getThresholdValues();

							if (conditionalOperator.equalsIgnoreCase("Property value changed")) {
								functionName = functionName + "_" + "PROPERTY_VALUE_CHANGED";
								drlTemplate = drlTemplates.get(functionName);
								if (drlTemplate != null) {
									actualSubStepDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId)
											.replaceAll("<RULE_VERSION>", ruleVersion + "")
											.replaceAll("<SALIENCE>", salience + "")
											.replaceAll("<STEPNUMBER>", stepNumber + "")
											.replaceAll("<SUB_STEPNUMBER>", subStepNumber + "")
											.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "")
											.replaceAll("<WIRE_INPUT>", name)
											.replaceAll("<TIMEPERIOD>", timePeriodInMilliSeconds + "");
								}
							} else if (expressionType.equalsIgnoreCase("THRESHOLD")) {
								functionName = functionName + "_" + "THRESHOLD";
								drlTemplate = drlTemplates.get(functionName);
								if (drlTemplate != null) {
									actualSubStepDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId)
											.replaceAll("<RULE_VERSION>", ruleVersion + "")
											.replaceAll("<SALIENCE>", salience + "")
											.replaceAll("<STEPNUMBER>", stepNumber + "")
											.replaceAll("<SUB_STEPNUMBER>", subStepNumber + "")
											.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "")
											.replaceAll("<TIMEPERIOD>", timePeriodInMilliSeconds + "")
											.replaceAll("<WIRE_INPUT>", name).replaceAll("<COND>", conditionalOperator)
											.replaceAll("<THRESHOLDVALUE>", thresholdValue);
								}
							} else if (expressionType.equalsIgnoreCase("STRING")) {
								functionName = "ERRORCODE";
								drlTemplate = drlTemplates.get(functionName);
								if (drlTemplate != null) {
									actualSubStepDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId)
											.replaceAll("<RULE_VERSION>", ruleVersion + "")
											.replaceAll("<SALIENCE>", salience + "")
											.replaceAll("<STEPNUMBER>", stepNumber + "")
											.replaceAll("<SUB_STEPNUMBER>", subStepNumber + "")
											.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "")
											.replaceAll("<TIMEPERIOD>", timePeriodInMilliSeconds + "")
											.replaceAll("<WIRE_INPUT>", name).replaceAll("<COND>", conditionalOperator)
											.replaceAll("<THRESHOLDVALUE>", thresholdValue);
								}
							} else {
								drlTemplate = drlTemplates.get(functionName);
								if (drlTemplate != null) {

									int i = 0;
									String values = "";
									values += thresholdValues[i] + "\"" + ",";
									i++;
									while (i < thresholdValues.length - 1) {
										values += "\"" + thresholdValues[i] + "\"" + ",";

										i++;
									}
									values += "\"" + thresholdValues[i];

									actualSubStepDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId)
											.replaceAll("<RULE_VERSION>", ruleVersion + "")
											.replaceAll("<SALIENCE>", salience + "")
											.replaceAll("<STEPNUMBER>", stepNumber + "")
											.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "")
											.replaceAll("<SUB_STEPNUMBER>", subStepNumber + "")
											.replaceAll("<TIMEPERIOD>", timePeriodInMilliSeconds + "")
											.replaceAll("<WIRE_INPUT>", name).replaceAll("<COND>", conditionalOperator)
											.replaceAll("<THRESHOLDVALUE>", values);
								}
							}
						}
					} else {
						drlTemplate = drlTemplates.get(functionName);
						if (drlTemplate != null) {
							StringBuilder wireInputBuilder = new StringBuilder();
							for (String wireInput : wiringInput) {
								wireInputBuilder.append(",").append("\"").append(wireInput).append("\"");
							}
							String wireInputs = wireInputBuilder.substring(1, wireInputBuilder.length());
							actualSubStepDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId)
									.replaceAll("<RULE_VERSION>", ruleVersion + "")
									.replaceAll("<SALIENCE>", salience + "").replaceAll("<STEPNUMBER>", stepNumber + "")
									.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "")
									.replaceAll("<SUB_STEPNUMBER>", subStepNumber + "")
									.replaceAll("<TIMEPERIOD>", timePeriodInMilliSeconds + "")
									.replaceAll("<FUNCTIONCALL>", expression).replaceAll("<WIRE_INPUTS>", wireInputs)
									.replaceAll("<WIRE_INPUTS_STRING>", wiringInput.toString());

						}
					}
					ruleSubStepsStringBuilder.append(actualSubStepDrl).append(NEW_LINE).append(NEW_LINE);
					/**
					 * In the template, for Step, it would have details as .1
					 * and .2 for substeps, since the order of the sub-steps is
					 * immaterial Here, the .1 is replaced with actual value to
					 * evaluate for AND, OR or NA. Please refer AND, OR
					 * templates for more details
					 */
					subStepStrings.put(
							"<RULE_ID>.VER <RULE_VERSION>.STEP <STEPNUMBER>.SUBSTEP <SUB_STEPNUMBER>.TRIGGERED" + "."
									+ subStepCount,
							ruleId + ".VER " + ruleVersion + ".STEP " + stepNumber + ".SUBSTEP " + subStepNumber
									+ ".TRIGGERED");

				}
				ruleStepStringBuilder.append(ruleSubStepsStringBuilder.toString());
				int i = subSteps.size();

				String s = Integer.toString(i);

				String stepDrlTemplate = drlTemplates.get(operator + s);
				if (stepDrlTemplate != null) {
					String actualStepDrl = stepDrlTemplate;
					for (Map.Entry<String, String> subStepString : subStepStrings.entrySet()) {
						String key = subStepString.getKey();
						String value = subStepString.getValue();
						actualStepDrl = actualStepDrl.replaceAll(key, value);
					}
					--salience;
					actualStepDrl = actualStepDrl.replaceAll("<RULE_ID>", ruleId)
							.replaceAll("<RULE_VERSION>", ruleVersion + "").replaceAll("<STEPNUMBER>", stepNumber + "")
							.replaceAll("<SALIENCE>", salience + "")
							.replaceAll("<PREV_STEP_NUMBER>", previousStepNumber + "");
					ruleStepStringBuilder.append(actualStepDrl).append(NEW_LINE).append(NEW_LINE);
				}

			}
			ruleStringBuilder.append(ruleStepStringBuilder.toString()).append(NEW_LINE);
		}
		--salience;
		/**
		 * END/OUTPUT RULE
		 */
		drlTemplate = drlTemplates.get("OUTPUT");
		String actualOutputDrl = null;
		if (drlTemplate != null) {
			actualOutputDrl = drlTemplate.replaceAll("<RULE_ID>", ruleId).replaceAll("<RULE_VERSION>", ruleVersion + "")
					.replaceAll("<MAX_STEP_NUMBER>", maxStepNumber + "").replaceAll("<SALIENCE>", salience + "");

		}
		ruleStringBuilder.append(actualOutputDrl).append(NEW_LINE);

		/**
		 * ADD ALL FUNCTIONS at the last for compilation
		 */
		/*
		 * drlTemplate = drlTemplates.get("FUNCTIONS");
		 * ruleStringBuilder.append(drlTemplate).append(NEW_LINE).append(
		 * NEW_LINE);
		 */
		System.out.println(ruleStringBuilder.toString());
		ruleData = ruleStringBuilder.toString();
		return ruleData;
	}

	private Map<String, String> getAllTemplates() {
		IOFileFilter dirfilter = TrueFileFilter.INSTANCE;
		IOCase caseInSensitive = IOCase.INSENSITIVE;
		IOFileFilter fileFilter = new WildcardFileFilter("*.drl", caseInSensitive);
		Map<String, String> drlTemplates = new HashMap<String, String>();

		String directory = "C:/test/drl/";

		File dirPath = new File(directory);
		Collection<File> fileCollection = FileUtils.listFiles(dirPath, fileFilter, dirfilter);
		if (fileCollection != null && !fileCollection.isEmpty()) {
			try {
				for (File file : fileCollection) {
					String fileName = FilenameUtils.getBaseName(file.getName());
					String fileContents = FileUtils.readFileToString(file);
					drlTemplates.put(fileName, fileContents);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			// System.out.println(drlTemplates);
		}

		return drlTemplates;
	}

	public Set<String> executeRules(Collection<SystemMonitoredProperties> smpObjs, String[] fileNames) {
		RSRuleOutputObject rsRuleOutputObject = new RSRuleOutputObject();
		Set<SystemMonitoredProperties> triggeredDataPoints = new HashSet<SystemMonitoredProperties>();
		Set<String> triggerStrings = new LinkedHashSet<String>();
		final KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();
		int j = 0;
		while (j < fileNames.length) {
			kbuilder.add(ResourceFactory.newFileResource(fileNames[j]), ResourceType.DRL);
			j++;
		}
		// Check the builder for errors

		if (kbuilder.hasErrors()) {
			System.out.println(kbuilder.getErrors().toString());
			throw new RuntimeException("Unable to compile \"drl file\".");
		}
		final Collection<KnowledgePackage> pkgs = kbuilder.getKnowledgePackages();
		final KnowledgeBase kbase = KnowledgeBaseFactory.newKnowledgeBase();

		kbase.addKnowledgePackages(pkgs);

		final StatelessKnowledgeSession ksession = kbase.newStatelessKnowledgeSession();

		ksession.setGlobal("rsRuleOutputObject", rsRuleOutputObject);
		ksession.setGlobal("triggeredDataPoints", triggeredDataPoints);
		ksession.setGlobal("triggerStrings", triggerStrings);

		ksession.execute(smpObjs);
		System.out.println("triggerDataCollection - " + triggerStrings);
		return triggerStrings;
	}

	/**
	 * @param expString
	 * @return
	 */
	private Expression parseExpression(String expString) {

		/**
		 * This function parses the below expressions for Error code or Property
		 * (SW REVISION) Property value changed (NEW_VALUE) 1. (FAULT_CODE) ==
		 * (25) -- This is for Error code 2. (HePressure) > (#4) -- This is for
		 * Property which has a condition w.r.t Double/Integer value 3.
		 * (HePressure) > (str(HELLO)) -- This is for property which has a
		 * condition w.r.t String value 4. (He Pressure) > (He Pressure HiLimit)
		 * -- This is for Property which has condition w.r.t Threshold limit 5.
		 * (FAULT_CODE) == {25,26,27} -- This is for Error code
		 */
		Expression expression = null;

		if (expString != null && expString.indexOf("(") >= 0 && expString.indexOf(")") >= 0) {
			expression = new Expression();
			if (expString.contains("{")) {
				String expressionType = null;
				String name = expString.substring(expString.indexOf("(") + 1, expString.indexOf(")"));
				String operator = expString.substring(expString.indexOf(") ") + 1, expString.indexOf("{"));

				String Values = expString.substring(expString.indexOf("{") + 1, expString.lastIndexOf("}"));
				String[] thresholdValues = Values.split(",");
				expression.setThresholdValues(thresholdValues);
				expression.setName(name);
				expressionType = "ERRORCODE";
				expression.setOperator(operator);
				expression.setExpressionType(expressionType);
			} else {
				String expressionType = null;
				String name = expString.substring(expString.indexOf("(") + 1, expString.indexOf(")"));
				String operator = expString.substring(expString.indexOf(") ") + 1, expString.lastIndexOf(" ("));

				String thresholdValue = expString.substring(expString.lastIndexOf("(") + 1, expString.lastIndexOf(")"));

				if (thresholdValue.contains("#")) {
					expressionType = "VALUE";
					thresholdValue = thresholdValue.replace("#", "");
				} else if (thresholdValue.contains("str")) {
					expressionType = "STRING";
					thresholdValue = thresholdValue.replace("str", "");

				}

				else {
					expressionType = "THRESHOLD";
				}
				expression.setThresholdValue(thresholdValue);
				expression.setName(name);
				expression.setOperator(operator);
				expression.setExpressionType(expressionType);
			}

		}

		return expression;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RuleConstructor ruleConstructor = new RuleConstructor();
		// ruleConstructor.testCountValueFunction();
		// ruleConstructor.testCountExpressionValueFunction();
		// ruleConstructor.testNoDataAvailableFunction();
		// ruleConstructor.testInSpecFunction();
		// ruleConstructor.testOutOfSpecFunction();

		try {
			ruleConstructor.testPropertyErrorCode();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Set<String> testPropertyErrorCode() throws JsonParseException, JsonMappingException, IOException {
		/**
		 * Test error code, parameter rule
		 */
		ArrayList<SystemMonitoredProperties> smpobjs = new ArrayList<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("FAULT_CODE");
		systemMonitoredProperties1.setMonitorValue("1090476");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		SystemMonitoredProperties systemMonitoredProperties2 = new SystemMonitoredProperties();
		systemMonitoredProperties2.setPropertyCode("FAULT_CODE");
		systemMonitoredProperties2.setMonitorValue("212421773");
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.MINUTE, -5);
		systemMonitoredProperties2.setGeneratedAt(cal2);
		systemMonitoredProperties2.setReceivedAt(cal2);
		systemMonitoredProperties2.setGeneratedAtInMillis(cal2.getTimeInMillis());
		systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis());

		SystemMonitoredProperties systemMonitoredProperties3 = new SystemMonitoredProperties();
		systemMonitoredProperties3.setPropertyCode("FAULT_CODE");
		systemMonitoredProperties3.setMonitorValue("1000232");
		Calendar cal3 = Calendar.getInstance();
		cal3.set(Calendar.MINUTE, -5);
		systemMonitoredProperties3.setGeneratedAt(cal3);
		systemMonitoredProperties3.setReceivedAt(cal3);
		systemMonitoredProperties3.setGeneratedAtInMillis(cal3.getTimeInMillis());
		systemMonitoredProperties3.setReceivedAtInMillis(cal3.getTimeInMillis());

		SystemMonitoredProperties systemMonitoredProperties4 = new SystemMonitoredProperties();
		systemMonitoredProperties4.setPropertyCode("FAULT_CODE");
		systemMonitoredProperties4.setMonitorValue("21242668");
		Calendar cal4 = Calendar.getInstance();
		cal4.set(Calendar.MINUTE, -5);
		systemMonitoredProperties4.setGeneratedAt(cal4);
		systemMonitoredProperties4.setReceivedAt(cal4);
		systemMonitoredProperties4.setGeneratedAtInMillis(cal4.getTimeInMillis());
		systemMonitoredProperties4.setReceivedAtInMillis(cal4.getTimeInMillis());

		SystemMonitoredProperties systemMonitoredProperties5 = new SystemMonitoredProperties();
		systemMonitoredProperties5.setPropertyCode("FAULT_CODE");
		systemMonitoredProperties5.setMonitorValue("1090476");
		Calendar cal5 = Calendar.getInstance();
		cal5.set(Calendar.MINUTE, -5);
		systemMonitoredProperties5.setGeneratedAt(cal5);
		systemMonitoredProperties5.setReceivedAt(cal5);
		systemMonitoredProperties5.setGeneratedAtInMillis(cal5.getTimeInMillis());
		systemMonitoredProperties5.setReceivedAtInMillis(cal5.getTimeInMillis());
		smpobjs.add(systemMonitoredProperties4);
		smpobjs.add(systemMonitoredProperties5);
		smpobjs.add(systemMonitoredProperties2);
		smpobjs.add(systemMonitoredProperties3);

		RuleStepsConstructor rsc = new RuleStepsConstructor();
		int j = 0;
		MainTest mt = new MainTest();
		RuleSteps[] rst = rsc.constructRuleSteps(mt);
		String[] fileNames = new String[rst.length];
		while (j < rst.length) {
			String ruleContents = constructRule(rst[j]);
			String ruleName = rst[j].ruleName;

			try {
				FileUtils.writeStringToFile(new File("C:/test/drl/" + ruleName + ".drl"), ruleContents);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(smpobjs);

			fileNames[j] = "C:/test/drl/" + ruleName + ".drl";
			j++;
		}
		Set<String> output = executeRules(smpobjs, fileNames);
		return output;

	}

	public void testPropertyValueChanged() {
		/**
		 * Has property value changed
		 */
		Set<SystemMonitoredProperties> smpobjs = new HashSet<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("SW REVISION");
		systemMonitoredProperties1.setMonitorValue("1.67");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		SystemMonitoredProperties systemMonitoredProperties2 = new SystemMonitoredProperties();
		systemMonitoredProperties2.setPropertyCode("SW REVISION");
		systemMonitoredProperties2.setMonitorValue("1.68");
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.MINUTE, -5);
		systemMonitoredProperties2.setGeneratedAt(cal2);
		systemMonitoredProperties2.setReceivedAt(cal2);
		systemMonitoredProperties2.setGeneratedAtInMillis(cal2.getTimeInMillis());
		systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties2);

		LinkedList<Step> steps = new LinkedList<Step>();

		Set<SubStep> subSteps1 = new HashSet<SubStep>();
		SubStep subStep12 = new SubStep();
		Integer subStepNumber = 11;
		Set<String> wiringInput = null;
		Object wiringOutput = null;
		String expression = "(SW REVISION) Property value changed (NEW_VALUE)";
		Long timePeriodInMilliSeconds = 86400000L;
		String functionName = "PROPERTY";
		subStep12.setSubStepNumber(subStepNumber);
		subStep12.setWiringInput(wiringInput);
		subStep12.setWiringOutput(wiringOutput);
		subStep12.setExpression(expression);
		subStep12.setTimePeriodInMilliSeconds(timePeriodInMilliSeconds);
		subStep12.setFunctionName(functionName);
		subSteps1.add(subStep12);

		Step step1 = new Step();
		Integer stepNumber = 1;
		String operator = "NA";
		step1.setStepNumber(stepNumber);
		step1.setOperator(operator);
		step1.setSubStep(subSteps1);
		steps.add(step1);

		RuleSteps ruleSteps1 = new RuleSteps();
		String ruleName = "TESTRULE";
		String ruleId = "MAC001010";
		int ruleVersion = 1;
		LinkedList<Step> step = steps;
		ruleSteps1.setRuleName(ruleName);
		ruleSteps1.setRuleId(ruleId);
		ruleSteps1.setRuleVersion(ruleVersion);
		ruleSteps1.setStep(step);

		String ruleContents = constructRule(ruleSteps1);

		try {
			FileUtils.writeStringToFile(new File("C:/test/drl/test3.drl"), ruleContents);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(smpobjs);

	}

	public void testCountExpressionValueFunction() {
		Set<SystemMonitoredProperties> smpobjs = new HashSet<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("HePressure");
		systemMonitoredProperties1.setMonitorValue("5");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		SystemMonitoredProperties systemMonitoredProperties2 = new SystemMonitoredProperties();
		systemMonitoredProperties2.setPropertyCode("HePressure");
		systemMonitoredProperties2.setMonitorValue("6");
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.MINUTE, -5);
		systemMonitoredProperties2.setGeneratedAt(cal2);
		systemMonitoredProperties2.setReceivedAt(cal2);
		systemMonitoredProperties2.setGeneratedAtInMillis(cal2.getTimeInMillis());
		systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties2);

		SystemMonitoredProperties systemMonitoredProperties3 = new SystemMonitoredProperties();
		systemMonitoredProperties3.setPropertyCode("HePressureHighLimit");
		systemMonitoredProperties3.setMonitorValue("4");
		Calendar cal3 = Calendar.getInstance();
		cal3.set(Calendar.MINUTE, -10);
		systemMonitoredProperties3.setGeneratedAt(cal3);
		systemMonitoredProperties3.setReceivedAt(cal3);
		systemMonitoredProperties3.setGeneratedAtInMillis(cal3.getTimeInMillis());
		systemMonitoredProperties3.setReceivedAtInMillis(cal3.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties3);

		LinkedList<Step> steps = new LinkedList<Step>();

		Set<SubStep> subSteps1 = new HashSet<SubStep>();
		SubStep subStep12 = new SubStep();
		Integer subStepNumber = 11;
		Set<String> wiringInput = new HashSet<String>();
		wiringInput.add("HePressure");
		// wiringInput.add("HePressureHighLimit");
		Object wiringOutput = null;
		String expression = "CountExpressionValue::HePressure,>=,4,>,2";
		Long timePeriodInMilliSeconds = 86400000L;
		String functionName = "COUNT_EXPRESSION_VALUE";
		subStep12.setSubStepNumber(subStepNumber);
		subStep12.setWiringInput(wiringInput);
		subStep12.setWiringOutput(wiringOutput);
		subStep12.setExpression(expression);
		subStep12.setTimePeriodInMilliSeconds(timePeriodInMilliSeconds);
		subStep12.setFunctionName(functionName);
		subSteps1.add(subStep12);

		Step step1 = new Step();
		Integer stepNumber = 1;
		String operator = "NA";
		step1.setStepNumber(stepNumber);
		step1.setOperator(operator);
		step1.setSubStep(subSteps1);
		steps.add(step1);

		RuleSteps ruleSteps1 = new RuleSteps();
		String ruleName = "TESTRULE";
		String ruleId = "MAC001010";
		int ruleVersion = 1;
		LinkedList<Step> step = steps;
		ruleSteps1.setRuleName(ruleName);
		ruleSteps1.setRuleId(ruleId);
		ruleSteps1.setRuleVersion(ruleVersion);
		ruleSteps1.setStep(step);
		System.out.println(ruleSteps1);
		String ruleContents = constructRule(ruleSteps1);

		try {
			FileUtils.writeStringToFile(new File("C:/test/drl/test3.drl"), ruleContents);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(smpobjs);
		// executeRules(smpobjs,"C:/test/drl/test3.drl");

	}

	public void testNoDataAvailableFunction() {
		Set<SystemMonitoredProperties> smpobjs = new HashSet<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("HePressure");
		systemMonitoredProperties1.setMonitorValue("5");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		SystemMonitoredProperties systemMonitoredProperties2 = new SystemMonitoredProperties();
		systemMonitoredProperties2.setPropertyCode("HeLevel");
		systemMonitoredProperties2.setMonitorValue("6");
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.HOUR, -2);
		systemMonitoredProperties2.setGeneratedAt(cal2);
		systemMonitoredProperties2.setReceivedAt(cal2);
		systemMonitoredProperties2.setGeneratedAtInMillis(cal2.getTimeInMillis());
		systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties2);

		SystemMonitoredProperties systemMonitoredProperties3 = new SystemMonitoredProperties();
		systemMonitoredProperties3.setPropertyCode("HePressureHighLimit");
		systemMonitoredProperties3.setMonitorValue("4");
		Calendar cal3 = Calendar.getInstance();
		cal3.set(Calendar.MINUTE, -10);
		systemMonitoredProperties3.setGeneratedAt(cal3);
		systemMonitoredProperties3.setReceivedAt(cal3);
		systemMonitoredProperties3.setGeneratedAtInMillis(cal3.getTimeInMillis());
		systemMonitoredProperties3.setReceivedAtInMillis(cal3.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties3);

		LinkedList<Step> steps = new LinkedList<Step>();

		Set<SubStep> subSteps1 = new HashSet<SubStep>();
		SubStep subStep12 = new SubStep();
		Integer subStepNumber = 11;
		Set<String> wiringInput = new HashSet<String>();
		wiringInput.add("HeLevel");
		// wiringInput.add("HePressureHighLimit");
		Object wiringOutput = null;
		String expression = "NO_DATA_AVAILABLE::HeLevel";
		Long timePeriodInMilliSeconds = 86400000L;
		String functionName = "NO_DATA_AVAILABLE";
		subStep12.setSubStepNumber(subStepNumber);
		subStep12.setWiringInput(wiringInput);
		subStep12.setWiringOutput(wiringOutput);
		subStep12.setExpression(expression);
		subStep12.setTimePeriodInMilliSeconds(timePeriodInMilliSeconds);
		subStep12.setFunctionName(functionName);
		subSteps1.add(subStep12);

		Step step1 = new Step();
		Integer stepNumber = 1;
		String operator = "NA";
		step1.setStepNumber(stepNumber);
		step1.setOperator(operator);
		step1.setSubStep(subSteps1);
		steps.add(step1);

		RuleSteps ruleSteps1 = new RuleSteps();
		String ruleName = "TESTRULE";
		String ruleId = "MAC001010";
		int ruleVersion = 1;
		LinkedList<Step> step = steps;
		ruleSteps1.setRuleName(ruleName);
		ruleSteps1.setRuleId(ruleId);
		ruleSteps1.setRuleVersion(ruleVersion);
		ruleSteps1.setStep(step);
		System.out.println(ruleSteps1);
		String ruleContents = constructRule(ruleSteps1);

		try {
			FileUtils.writeStringToFile(new File("C:/test/drl/test3.drl"), ruleContents);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(smpobjs);
		// executeRules(smpobjs,"C:/test/drl/test3.drl");
	}

	public void testInSpecFunction() {
		Set<SystemMonitoredProperties> smpobjs = new HashSet<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("HePressure");
		systemMonitoredProperties1.setMonitorValue("4");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		SystemMonitoredProperties systemMonitoredProperties2 = new SystemMonitoredProperties();
		systemMonitoredProperties2.setPropertyCode("HePressureLoLimit");
		systemMonitoredProperties2.setMonitorValue("3");
		Calendar cal2 = Calendar.getInstance();
		cal2.set(Calendar.HOUR, -1);
		systemMonitoredProperties2.setGeneratedAt(cal2);
		systemMonitoredProperties2.setReceivedAt(cal2);
		systemMonitoredProperties2.setGeneratedAtInMillis(cal2.getTimeInMillis());
		systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties2);

		SystemMonitoredProperties systemMonitoredProperties3 = new SystemMonitoredProperties();
		systemMonitoredProperties3.setPropertyCode("HePressureHiLimit");
		systemMonitoredProperties3.setMonitorValue("5");
		Calendar cal3 = Calendar.getInstance();
		cal3.set(Calendar.MINUTE, -10);
		systemMonitoredProperties3.setGeneratedAt(cal3);
		systemMonitoredProperties3.setReceivedAt(cal3);
		systemMonitoredProperties3.setGeneratedAtInMillis(cal3.getTimeInMillis());
		systemMonitoredProperties3.setReceivedAtInMillis(cal3.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties3);

		LinkedList<Step> steps = new LinkedList<Step>();

		Set<SubStep> subSteps1 = new HashSet<SubStep>();
		SubStep subStep12 = new SubStep();
		Integer subStepNumber = 11;
		Set<String> wiringInput = new HashSet<String>();
		wiringInput.add("HePressure");
		wiringInput.add("HePressureHiLimit");
		// wiringInput.add("HePressureLoLimit");
		Object wiringOutput = null;
		String expression = "InSpec::HePressure,HePressureHiLimit,3";
		Long timePeriodInMilliSeconds = 86400000L;
		String functionName = "INSPEC";
		subStep12.setSubStepNumber(subStepNumber);
		subStep12.setWiringInput(wiringInput);
		subStep12.setWiringOutput(wiringOutput);
		subStep12.setExpression(expression);
		subStep12.setTimePeriodInMilliSeconds(timePeriodInMilliSeconds);
		subStep12.setFunctionName(functionName);
		subSteps1.add(subStep12);

		Step step1 = new Step();
		Integer stepNumber = 1;
		String operator = "NA";
		step1.setStepNumber(stepNumber);
		step1.setOperator(operator);
		step1.setSubStep(subSteps1);
		steps.add(step1);

		RuleSteps ruleSteps1 = new RuleSteps();
		String ruleName = "TESTRULE";
		String ruleId = "MAC001010";
		int ruleVersion = 1;
		LinkedList<Step> step = steps;
		ruleSteps1.setRuleName(ruleName);
		ruleSteps1.setRuleId(ruleId);
		ruleSteps1.setRuleVersion(ruleVersion);
		ruleSteps1.setStep(step);
		System.out.println(ruleSteps1);
		String ruleContents = constructRule(ruleSteps1);

		try {
			FileUtils.writeStringToFile(new File("C:/test/drl/test3.drl"), ruleContents);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println(smpobjs);
		// executeRules(smpobjs,"C:/test/drl/test3.drl");

	}

	public void testOutOfSpecFunction() {
		Set<SystemMonitoredProperties> smpobjs = new HashSet<SystemMonitoredProperties>();
		SystemMonitoredProperties systemMonitoredProperties1 = new SystemMonitoredProperties();
		systemMonitoredProperties1.setPropertyCode("FAULTCODE");
		systemMonitoredProperties1.setMonitorValue("25");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.MINUTE, -2);
		systemMonitoredProperties1.setGeneratedAt(cal);
		systemMonitoredProperties1.setReceivedAt(cal);
		systemMonitoredProperties1.setGeneratedAtInMillis(cal.getTimeInMillis());
		systemMonitoredProperties1.setReceivedAtInMillis(cal.getTimeInMillis());

		smpobjs.add(systemMonitoredProperties1);

		/*
		 * SystemMonitoredProperties systemMonitoredProperties2 = new
		 * SystemMonitoredProperties();
		 * systemMonitoredProperties2.setPropertyCode("HePressureLoLimit");
		 * systemMonitoredProperties2.setMonitorValue("3"); Calendar cal2 =
		 * Calendar.getInstance(); cal2.set(Calendar.HOUR, -1);
		 * systemMonitoredProperties2.setGeneratedAt(cal2);
		 * systemMonitoredProperties2.setReceivedAt(cal2);
		 * systemMonitoredProperties2.setGeneratedAtInMillis(cal2.
		 * getTimeInMillis());
		 * systemMonitoredProperties2.setReceivedAtInMillis(cal2.getTimeInMillis
		 * ());
		 * 
		 * smpobjs.add(systemMonitoredProperties2);
		 * 
		 * SystemMonitoredProperties systemMonitoredProperties3 = new
		 * SystemMonitoredProperties();
		 * systemMonitoredProperties3.setPropertyCode("HePressureHiLimit");
		 * systemMonitoredProperties3.setMonitorValue("5"); Calendar cal3 =
		 * Calendar.getInstance(); cal3.set(Calendar.MINUTE, -10);
		 * systemMonitoredProperties3.setGeneratedAt(cal3);
		 * systemMonitoredProperties3.setReceivedAt(cal3);
		 * systemMonitoredProperties3.setGeneratedAtInMillis(cal3.
		 * getTimeInMillis());
		 * systemMonitoredProperties3.setReceivedAtInMillis(cal3.getTimeInMillis
		 * ());
		 * 
		 * smpobjs.add(systemMonitoredProperties3);
		 * 
		 * LinkedList<Step> steps = new LinkedList<Step>();
		 * 
		 * Set<SubStep> subSteps1 = new HashSet<SubStep>(); SubStep subStep12 =
		 * new SubStep(); Integer subStepNumber = 11; Set<String> wiringInput =
		 * new HashSet<String>(); wiringInput.add("HePressure");
		 * //wiringInput.add("HePressureHiLimit");
		 * //wiringInput.add("HePressureLoLimit"); Object wiringOutput = null;
		 * String expression = "OutOfSpec::HePressure,3,2"; Long
		 * timePeriodInMilliSeconds = 86400000L; String functionName =
		 * "OUT_OF_SPEC"; subStep12.setSubStepNumber(subStepNumber);
		 * subStep12.setWiringInput(wiringInput);
		 * subStep12.setWiringOutput(wiringOutput);
		 * subStep12.setExpression(expression);
		 * subStep12.setTimePeriodInMilliSeconds(timePeriodInMilliSeconds);
		 * subStep12.setFunctionName(functionName); subSteps1.add(subStep12);
		 * 
		 * Step step1 = new Step(); Integer stepNumber = 1; String operator =
		 * "NA"; step1.setStepNumber(stepNumber); step1.setOperator(operator);
		 * step1.setSubStep(subSteps1); steps.add(step1);
		 * 
		 * RuleSteps ruleSteps1 = new RuleSteps(); String ruleName = "TESTRULE";
		 * String ruleId = "MAC001010"; int ruleVersion = 1; LinkedList<Step>
		 * step = steps; ruleSteps1.setRuleName(ruleName);
		 * ruleSteps1.setRuleId(ruleId); ruleSteps1.setRuleVersion(ruleVersion);
		 * ruleSteps1.setStep(step); System.out.println(ruleSteps1); String
		 * ruleContents = constructRule(ruleSteps1);
		 * 
		 * try { FileUtils.writeStringToFile(new File("C:/test/drl/test3.drl"),
		 * ruleContents); } catch (IOException e) { // TODO Auto-generated catch
		 * block e.printStackTrace(); }
		 */
		System.out.println(smpobjs);
		// executeRules(smpobjs,"C:/test/drl/test3.drl");

	}
}
