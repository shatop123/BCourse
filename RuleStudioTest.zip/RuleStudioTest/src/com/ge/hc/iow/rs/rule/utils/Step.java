/* ************************************************************************
 * $RCSfile: $
 * $Revision: $
 * Author : Senthil N
 * Created on Aug 19, 2015
 * 
 * Copyright 2015 THE GENERAL ELECTRIC COMPANY.
 * This software is the confidential and proprietary information of the
 * General Electric Company (GE). You shall not disclose this software and
 * shall use it only in accordance with the terms of the license agreement
 * you entered into with GE.
 *
 * $Log: $
 * ************************************************************************/

package com.ge.hc.iow.rs.rule.utils;

import java.util.Set;

public class Step {

	Integer stepNumber;
	String operator;
	String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	Set<SubStep> subStep;
	
	public Integer getStepNumber() {
		return stepNumber;
	}
	public void setStepNumber(Integer stepNumber) {
		this.stepNumber = stepNumber;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	
	public Set<SubStep> getSubStep() {
		return subStep;
	}
	public void setSubStep(Set<SubStep> subStep) {
		this.subStep = subStep;
	}
	
}
