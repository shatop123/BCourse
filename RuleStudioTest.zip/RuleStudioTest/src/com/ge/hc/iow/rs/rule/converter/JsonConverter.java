package com.ge.hc.iow.rs.rule.converter;
import java.util.LinkedList;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;

public final class JsonConverter {
    public final Task task;

    @JsonCreator
    public JsonConverter(@JsonProperty("task") Task task){
        this.task = task;
    }

    public static final class Task {
        public final String name;
        public final Rule rules[];

        @JsonCreator
        public Task(@JsonProperty("name") String name, @JsonProperty("rules") Rule[] rules){
            this.name = name;
            this.rules = rules;
        }

        public static final class Rule {
            public final String name;
            public final String id;
            public final LinkedList<Steps> steps;
    
            @JsonCreator
            public Rule(@JsonProperty("name") String name,@JsonProperty("id") String id, @JsonProperty("steps") LinkedList<Steps> steps){
                this.name = name;
                this.id=id;
                this.steps = steps;
            }
    
            public static final class Steps {
                public final String name;
                public final String operator;
                public final Substeps[] substeps;
                public final String number;
                
        
                @JsonCreator
                public Steps(@JsonProperty("name") String name, @JsonProperty("operator") String operator, @JsonProperty("substeps") Substeps[] substeps,@JsonProperty("number") String number){
                    this.name = name;
                    this.operator = operator;
                    this.substeps = substeps;
                    this.number=number;
                }
        
                public static final class Substeps {
                    public final String name;
                    public final String function;
                    public final String expression;
                    public final String number;
					public final String timeperiod;
                    @JsonCreator
                    public Substeps(@JsonProperty("name") String name, @JsonProperty("function") String function, @JsonProperty("expression") String expression,@JsonProperty("number") String number,@JsonProperty("timeperiod") String timeperiod){
                        this.name = name;
                        this.function = function;
                        this.expression = expression;
                        this.number=number;
                        this.timeperiod=timeperiod;
                    }
                }
            }
        }
    }
}